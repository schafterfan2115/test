
public abstract class Schiff {
    String name;
    Person kaptain;
    Person[] crew;
    public Schiff() {
        String name;
        Person kaptain;
        Person[] crew;

    }

    public String tolist() {
        return "|" + name + "|" +"k" +kaptain.tolist() + "|" ;
    }

}
