public class Frachtschiff extends Schiff{
    int maxlade;
    int lade;
    public Frachtschiff(int _lade,int _maxlade) {
        super();
        maxlade=_maxlade;
        lade = _lade;
    }




    public int beladen(int i) throws Exception {
        if(i>0&&lade+i	<maxlade) {
            lade+=i;
        }else {
            throw new Exception((i+lade)-maxlade + " ist zu viel");
        }
        System.out.println("es wurde " + i + " aufbeladen und jetzt sind " + lade + " tonnen auf dem schiff drauf");
        return i;

    }
    public int entladen(int b) throws Exception {
        if(b>0&&lade-b>0) {
            lade-=b;
        }else {
            System.out.println(b);
            System.out.println(lade);
            throw new Exception("Zu viel!");
        }
        System.out.println("es wurden " + b + " entladen und jetzt sind " + lade + " tonnen auf dem schiff drauf");
        return b;

    }
    public void info() {
        System.out.println("Schiff:  " + name);
        System.out.println("Kaptain: " + kaptain.getVorName());
        System.out.println("Crew GroÃŸe: " + crew.length);
        System.out.println( lade + " Tonnen momentan geladen");
        System.out.println("Max " + maxlade + " geladen");
        System.out.println("Aktuell: " + (maxlade-lade));
    }

}
