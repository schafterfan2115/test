import java.time.LocalDate;

public class Person {
    String vorName;
    String nachName;
    int alter;
    public Person(String _vorName, String _nachName, int _alter) {

        setVorName(_vorName);
        setNachName(_nachName);
        setAlter(_alter);
    }
    public void setVorName(String __vorName) 		{vorName = __vorName;}
    public void setNachName(String __nachName) 		{nachName = __nachName;}
    public void setAlter(int __alter) 				{alter = __alter;}


    public String getVorName() 		{return vorName;}
    public String getNachName() 	{return nachName;}
    public int getAlter()			{return alter;}
    @Override
    public String toString() {
        return "Person [vorname=" + vorName + ", nachname=" + nachName + ", alter=" + alter + "]";
    }

        public String tolist() {
            return ";" + vorName + ";" + nachName + ";" + alter;
        }




}
