import java.time.LocalDate;

public class Main {
    public static void main(String[] args) throws Exception {


        try {

            Ausflugsboot gawad = new Ausflugsboot();
            gawad.impcrew();
            //			Schiff f = new Frachtschiff();
            //			((Frachtschiff) f).beladen(299);
            //			((Frachtschiff) f).entladen(400);
            //			((Frachtschiff) f).entladen(400);
            //			((Frachtschiff) f).beladen(299);
            //

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
