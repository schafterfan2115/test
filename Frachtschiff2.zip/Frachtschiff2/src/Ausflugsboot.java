import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Pattern;

public class Ausflugsboot extends Schiff {
    Person[] crew = new Person[3];
    public Ausflugsboot() throws Exception {
        super();
        impcrew();
        checkcrew(crew);
        writecrew();
    }
    private void writecrew() throws IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter("Daten2.txt"));

        bw.write(tolist());
        bw.close();
    }

    void impcrew() throws Exception {
        String[] temp;
        String[] temp2;
        int b=0;
        BufferedReader br = new BufferedReader(new FileReader("Daten.txt"));
        String line;
        line = br.readLine();
        System.out.println(line);
        temp = line.split(Pattern.quote("|"));

        name =temp[1];

        if(temp[0].charAt(0)=='A') {
            for (int i = 2; i < 6; i++) {
                temp2 = temp[i].split(";");
                if(temp2[0].charAt(0)=='k') {
                    kaptain = new Person(temp2[1],temp2[2],Integer.parseInt(temp2[3]));

                }else {
                    crew[b] = new Person(temp2[1], temp2[2], Integer.parseInt(temp2[3]));
                    b++;
                }
            }
        }
        System.out.println(tolist());
        br.close();
    }

    private void checkcrew(Person[] p) throws Exception {
        if(p.length>20) {
            throw new Exception("es sind zu viele leute auf dem schiff");
        }else {
            for (int i = 0; i < p.length; i++) {
                crew[i]=p[i];
            }
        }
    }



    public void info() {
        System.out.println("das schiff heiÃŸt " + name);
        System.out.println("der kaptain heiÃŸt " + kaptain.getVorName());
        System.out.println("in der crew sind " + crew.length + " leute drin");
    }
    public void mittelalter() {
        System.out.println(crew.length);
        int b = 0;
        int count= 0;
        for (int i = 0; i < crew.length; i++) {
            if (crew[i] != null) {
                b=b+crew[i].getAlter();
                count++;
            }
        }

        b=b/count;


        System.out.println(b);

    }

    public String tolist() {
        return "A" + super.tolist() + "c" + crew[0].tolist() + "|c" + crew[1].tolist() + "|c" + crew[2].tolist();
    }

}

