import javax.swing.*;
import java.awt.*;

public class GUI1 extends JFrame {


    JButton taste = new JButton("In Großbuchstaben");
    JButton ende = new JButton("Beenden");

    JTextField text1 = new JTextField(10);
    JTextField text2 = new JTextField(10);

    public GUI1(){
        super("In Groß Buchstaben Umwandeln");
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.setBackground(Color.LIGHT_GRAY);

        JPanel pl = new JPanel();
       // pl.setSize(500,200);
        cp.add(pl, BorderLayout.NORTH);


        JPanel p = new JPanel();
        JPanel center = new JPanel();
        center.setLayout(new FlowLayout(0));
        JLabel jlabel = new JLabel("Eingabe:");
        p.add(jlabel);
        jlabel.setBounds(0,20,500,50);
        jlabel.setFont(new Font("Arial", 1, 16));
        center.add(p);

        JPanel textf1 = new JPanel();
        textf1.add(text1);
        center.add(textf1);
       // cp.add(center, BorderLayout.CENTER);


        JPanel cent2 = new JPanel();
        JLabel ausg = new JLabel("Ausgabe:");
        cent2.add(ausg);
        ausg.setBounds(0,20,500,50);
        ausg.setFont(new Font("Arial", 1, 16));
        center.add(cent2);
      //  cp.add(center, BorderLayout.CENTER);

        JPanel austxt = new JPanel();
        text2.setEditable(false);
        austxt.add(text2);
        center.add(austxt);
        cp.add(center, BorderLayout.CENTER);


        JPanel southbuttons = new JPanel();
        southbuttons.setLayout(new FlowLayout(1));
        southbuttons.add(taste);
        southbuttons.add(ende);
        cp.add(southbuttons, BorderLayout.SOUTH);






        setSize(500,150);
        setVisible(true);
    }
}
