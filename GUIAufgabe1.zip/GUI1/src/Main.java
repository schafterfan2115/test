public class Main {

    public static void main(String[] args) {

    //GUI test = new GUI();


        GUI1 xd= new GUI1();
    }
}