import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame {

    JButton click =new JButton("CLICK");

    JButton exit =new JButton("EXIT");
    JTextField text1 = new JTextField(15);
    JTextField text2 = new JTextField(15);

    public GUI(){
        super("Erstes Programm");
        Container cp = getContentPane();
        cp.setLayout(new GridLayout(4,2,20,20));

        JPanel tnord = new JPanel();
        tnord.add(text1);
        tnord.setBackground(Color.GRAY);
        cp.add(tnord);
        cp.setBackground(Color.GRAY);

        JPanel tnoedit = new JPanel();
        text2.setEditable(false);
        text2.setText(text1.getText().toUpperCase());
        tnoedit.add(text2);
        tnoedit.setBackground(Color.GRAY);
        cp.add(tnoedit);


        JPanel clickbutton = new JPanel();
        clickbutton.add(click);
        cp.add(clickbutton);
        click.addActionListener(this::actionPerformed);
        text2.setText(text1.getText().toUpperCase());
        clickbutton.setBackground(Color.GRAY);


        JPanel exitbutton = new JPanel();
        exitbutton.add(exit);
        exit.addActionListener(new CloseListener());
        cp.add(exitbutton);
        exitbutton.setBackground(Color.GRAY);


        setSize(300,250);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent e){
        text2.setText(text1.getText().toUpperCase());
    }

    private class CloseListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }
    }
